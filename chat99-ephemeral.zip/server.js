const express = require('express');
const http = require('http');
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const { Server } = require('socket.io');
const User = require('./models/User');
const formatMessage = require('./utils/formatMessage');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/chat99';
const JWT_SECRET = process.env.JWT_SECRET || 'replace_this_with_a_strong_secret';

// Connect to MongoDB (users only)
mongoose.connect(MONGO_URI).then(()=>console.log('MongoDB connected')).catch(e=>console.error(e));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// --- User API: register / login / me ---
app.post('/api/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password) return res.status(400).json({ error: 'Champs manquants' });
    const existing = await User.findOne({ $or: [{ email }, { username }] });
    if (existing) return res.status(400).json({ error: 'Utilisateur déjà existant' });
    const hash = await bcrypt.hash(password, 10);
    const user = new User({ username, email, passwordHash: hash });
    await user.save();
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Erreur serveur' }); }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Champs manquants' });
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Utilisateur introuvable' });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(400).json({ error: 'Mot de passe incorrect' });
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Erreur serveur' }); }
});

app.get('/api/me', async (req, res) => {
  try {
    const auth = req.headers.authorization || req.cookies.token || '';
    const token = auth.startsWith('Bearer ') ? auth.split(' ')[1] : auth;
    if (!token) return res.status(401).json({ error: 'Non authentifié' });
    const data = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(data.id).lean();
    if (!user) return res.status(401).json({ error: 'Utilisateur introuvable' });
    res.json({ id: user._id, username: user.username, email: user.email });
  } catch (e) { console.error(e); res.status(401).json({ error: 'Token invalide' }); }
});

// serve index and auth page
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/auth.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'auth.html')));

// In-memory structures (ephemeral)
const MAIN = 'chat_principale';
const roomPasswords = {}; // { roomName: passwordString or null } <-- stored in memory only (NOT persisted)
const roomMessages = {};  // { roomName: [ {id, user, text, time, type} ] }  <-- ephemeral

// Socket auth via token in handshake
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (!token) return next(new Error('Authentication error'));
    const data = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(data.id).lean();
    if (!user) return next(new Error('Authentication error'));
    socket.data.user = { id: user._id.toString(), username: user.username };
    return next();
  } catch (e) {
    console.error('Socket auth error', e.message);
    return next(new Error('Authentication error'));
  }
});

// Helper: push ephemeral message into memory (bounded)
function pushMessage(room, message) {
  roomMessages[room] = roomMessages[room] || [];
  roomMessages[room].push(message);
  if (roomMessages[room].length > 500) roomMessages[room].shift();
}

io.on('connection', (socket) => {
  const username = socket.data.user.username;
  socket.data.room = MAIN;
  socket.join(MAIN);

  // send ephemeral history for main room (from memory only)
  socket.emit('history', roomMessages[MAIN] || []);
  socket.emit('system', formatMessage('System', `Bienvenue ${username} ! (messages éphémères)`));

  // request join flow with in-memory password handling
  socket.on('requestJoin', ({ room }) => {
    const r = (room || MAIN).toString().trim();
    if (!r) { socket.emit('joinError', 'Nom de salon invalide'); return; }
    if (typeof roomPasswords[r] === 'undefined') {
      // room doesn't exist -> ask creator for password (can be empty)
      socket.emit('needCreatePassword', { room: r });
    } else {
      if (roomPasswords[r] === null) socket.emit('joinRequired', { room: r, requiresPassword: false });
      else socket.emit('needPassword', { room: r, requiresPassword: true });
    }
  });

  socket.on('join', ({ username: u, room, password }) => {
    const r = (room || MAIN).toString().trim();
    if (!r) { socket.emit('joinError', 'Nom de salon invalide'); return; }

    // create room in memory if not exists, store password in memory only
    if (typeof roomPasswords[r] === 'undefined') {
      roomPasswords[r] = (password && String(password).length>0) ? String(password) : null;
      roomMessages[r] = roomMessages[r] || [];
    } else {
      const stored = roomPasswords[r];
      if (stored !== null && String(password || '') !== stored) {
        socket.emit('joinError', 'Mot de passe incorrect pour ce salon.');
        return;
      }
    }

    // leave previous and join new
    try { socket.leave(socket.data.room); } catch(e){}
    socket.data.username = u ? String(u).slice(0,32) : socket.data.user.username;
    socket.data.room = r;
    socket.join(r);

    // send ephemeral history for room (memory only)
    socket.emit('history', roomMessages[r] || []);
    socket.emit('joinSuccess', { room: r });
    socket.to(r).emit('system', formatMessage('System', `${socket.data.username} a rejoint ${r}.`));
  });

  socket.on('message', (msg) => {
    const text = (msg.text || '').toString().slice(0,2000);
    const type = msg.type === 'image' ? 'image' : 'text';
    const room = socket.data.room || MAIN;
    const message = { id: Date.now() + Math.random().toString(36).slice(2,8), user: socket.data.username, text, time: Date.now(), type };
    // push to in-memory only
    pushMessage(room, message);
    // broadcast to room
    io.to(room).emit('message', message);
  });

  socket.on('typing', (isTyping) => {
    const payload = { user: socket.data.username, typing: !!isTyping };
    socket.to(socket.data.room || MAIN).emit('typing', payload);
  });

  socket.on('disconnect', () => {
    if (socket.data.room) socket.to(socket.data.room).emit('system', formatMessage('System', `${socket.data.username} a quitté.`));
  });
});

server.listen(PORT, () => console.log(`Server running on ${PORT}`));
