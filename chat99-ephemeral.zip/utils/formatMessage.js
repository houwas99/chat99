module.exports = function formatMessage(user, text) {
  return { id: Date.now()+Math.random().toString(36).slice(2,8), user, text, time: Date.now(), type: 'system' };
};
