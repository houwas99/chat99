// chat.js : connects socket with token, handles UI + messages (ephemeral)
const token = localStorage.getItem('chat99_token');
if (!token) { location.href = '/auth.html'; }
const socket = io({ auth: { token } });

const messages = document.getElementById('messages');
const form = document.getElementById('form');
const input = document.getElementById('input');
const roomInput = document.getElementById('room');
const joinBtn = document.getElementById('btnJoin');
const headerRoom = document.getElementById('headerRoom');
const logoutBtn = document.getElementById('logoutBtn');

let myName = window.CHAT99_USER ? window.CHAT99_USER.username : 'Anonyme';
let myRoom = 'chat_principale';

function renderMessage(m, mine=false){
  if (m.type === 'system') {
    const el = document.createElement('div');
    el.className = 'msg system';
    el.textContent = `🔔 ${m.text}`;
    messages.appendChild(el);
    messages.scrollTop = messages.scrollHeight;
    return;
  }
  const el = document.createElement('div');
  el.className = 'msg' + (mine ? ' me' : '');
  const meta = document.createElement('div'); meta.className='meta'; meta.textContent = m.user + ' · ' + new Date(m.time).toLocaleTimeString();
  el.appendChild(meta);
  const p = document.createElement('div'); p.textContent = m.text; el.appendChild(p);
  messages.appendChild(el); messages.scrollTop = messages.scrollHeight;
}

socket.on('connect_error', (err) => { console.error('conn error', err); alert('Erreur d\'authentification socket.'); localStorage.removeItem('chat99_token'); location.href='/auth.html'; });

socket.on('history', (history) => { messages.innerHTML=''; history.forEach(m=>renderMessage(m, m.user === myName)); });

socket.on('message', (m) => { renderMessage(m, m.user === myName); });

socket.on('system', (m) => { renderMessage(m, false); });

joinBtn.addEventListener('click', ()=>{
  const r = roomInput.value.trim() || 'chat_principale';
  // request join flow (server will ask for password if new)
  socket.emit('requestJoin', { room: r });
  myRoom = r;
  headerRoom.textContent = (r==='chat_principale')?'Chat principale':r;
});

// handle prompts for password responses
socket.on('needCreatePassword', ({room}) => {
  const pwd = prompt(`Le salon "${room}" n'existe pas. Entrez un mot de passe pour le créer (laisser vide = aucun mot de passe):`);
  socket.emit('join', { username: myName, room, password: pwd || '' });
});

socket.on('needPassword', ({room}) => {
  const pwd = prompt(`Le salon "${room}" nécessite un mot de passe. Entrez le mot de passe:`);
  socket.emit('join', { username: myName, room, password: pwd || '' });
});

socket.on('joinRequired', ({room}) => {
  socket.emit('join', { username: myName, room, password: '' });
});

socket.on('joinError', (msg) => { alert('Erreur: ' + msg); });

socket.on('joinSuccess', ({room}) => { myRoom = room; headerRoom.textContent = (room==='chat_principale')?'Chat principale':room; });

form.addEventListener('submit', (e)=>{
  e.preventDefault();
  if (!input.value.trim()) return;
  socket.emit('message', { text: input.value.trim() });
  input.value = '';
});

logoutBtn.addEventListener('click', ()=>{ localStorage.removeItem('chat99_token'); location.href = '/auth.html'; });
