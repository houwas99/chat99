// auth-check.js : ensures user is logged in and connects socket with token
(async ()=>{
  const token = localStorage.getItem('chat99_token');
  if (!token) { location.href = '/auth.html'; return; }
  try {
    const res = await fetch('/api/me', { headers: { 'Authorization': 'Bearer ' + token } });
    if (!res.ok) { localStorage.removeItem('chat99_token'); location.href = '/auth.html'; return; }
    const me = await res.json();
    // expose current user info for chat script
    window.CHAT99_USER = me;
    document.getElementById('meName').textContent = me.username;
    // proceed to load socket in chat.js which reads token from localStorage
  } catch(e){ localStorage.removeItem('chat99_token'); location.href = '/auth.html'; }
})();
